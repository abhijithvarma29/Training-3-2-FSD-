import React from 'react'

// class Sidebar extends React.Component {
//     render() {
//         return(
//             <h1>Sidebar1</h1>
//         )
//     }
// }
// export default Sidebar;

const Sidebar = () => {
  return (
    <div>Sidebar</div>
  )
}

export default Sidebar