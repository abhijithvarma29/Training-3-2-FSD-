import React from 'react'
import ContextC2 from './ContextC2'

const ContextC1 = () => {
  return (
    <div>
        <ContextC2></ContextC2>
    </div>
  )
}

export default ContextC1