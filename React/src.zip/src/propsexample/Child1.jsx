import React from 'react'
import Child2 from './Child2'

const child1 = () => {
  return (
    <div>child1
        <Child2/>
    </div>
  )
}

export default child1