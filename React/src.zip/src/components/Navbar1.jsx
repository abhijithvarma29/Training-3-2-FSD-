import React from 'react';

// class Navbar1 extends React.Component {
//     render() {
//         return(
//             <div>
//                 <h1>Navbar</h1>
//             </div>
//         )
//     }
// }
// export default Navbar1;

const Navbar1 = () => {
  return (
    <div>Navbar</div>
  )
}

export default Navbar1
