import React from "react";

// class Main extends React.Component{
//     render(){
//         return(
//             <h1>main</h1>   
//         )
//     }
// }
// export default Main;

const Main = () => {
  return (
    <div>Main</div>
  )
}

export default Main