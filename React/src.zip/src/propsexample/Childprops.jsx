import React from 'react'

const Childprops = () => {
  return (
    <div>Childprops</div>
  )
}

export default Childprops