import React from 'react'

const Child5 = () => {
  return (
    <div>Child5</div>
  )
}

export default Child5