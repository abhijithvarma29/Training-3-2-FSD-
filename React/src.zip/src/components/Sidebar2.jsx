import React from 'react'

// class Sidebar2 extends React.Component {
//     render() {
//         return(
//           <h1>Sidebar2</h1>  
//         )
//     }
// }
// export default Sidebar2
const Sidebar2 = () => {
  return (
    <div>Sidebar2</div>
  )
}

export default Sidebar2