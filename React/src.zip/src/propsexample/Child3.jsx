import React from 'react'

const Child3 = () => {
  return (
    <div>Child3
        <Child4/>
    </div>
  )
}

export default Child3