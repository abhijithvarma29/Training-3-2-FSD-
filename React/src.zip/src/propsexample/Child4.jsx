import React from 'react'

const Child4 = () => {
  return (
    <div>Child4
        <Child5/>
    </div>
  )
}

export default Child4