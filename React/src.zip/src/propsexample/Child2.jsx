import React from 'react'

const Child2 = () => {
  return (
    <div>Child2
        <Child3/>
    </div>
  )
}

export default Child2