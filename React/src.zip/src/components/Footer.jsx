import React from 'react'

// class Footer extends React.Component {
//   render() {
//     return (
//       <div>Footer</div>
//     )
//   }
// }
// export default Footer;
const Footer = () => {
  return (
    <div>Footer</div>
  )
}

export default Footer